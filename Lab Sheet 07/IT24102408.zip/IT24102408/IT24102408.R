getwd()
setwd("C:\\Users\\Aathooran\\Desktop\\IT24102408")
getwd()
#Exercise#
#1st question
punif(25, 0, 40) - punif(10, 0, 40) 
#2nd question
pexp(2, rate = 1/3)
#3rd question 1st part
1 - pnorm(130, mean=100, sd=15) 
#3rd question 2nd part
qnorm(0.95, mean=100, sd=15) 

