getwd()
setwd("C:\\Users\\IT24102408\\Desktop\\IT24102408")
branch_data <- read.csv("Exercise.txt",header =TRUE)
fix(data)
attach(data)

#Branch - Categorical,Nominal
#Sales_X1-Numeric(continuous),Ratio
#Advertising_X2-Numeric Ratio
#Years_X3-Numeric (discrete),Ratio

boxplot(X1,main="Box plot for Team Attendence", outline=TRUE, outpch=8, horizontal=TRUE)
boxplot(X2,main="Box plot for Team Salary", outline=TRUE,outpch=8,horizontal=TRUE)
boxplot(X3,main="box plot for Years", outline=TRUE,outpch=8,horizontal=TRUE)


fivenum(Advertising_X2)
IQR(Advertising_X2)

get_outliers<-function(z){
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3- q1
  ub <- q3+1.5*iqr
  lb <- q1-1.5*iqr
  
  print(paste("Upper Bound = ",ub))
  print(paste("Lower Bound =",lb))
  print(paste("Outliers:",paste(sort(z[z < lb | z> ub]), collapse)))
  
  
  get_outliers(Sales_X1)
  get_outliers(Adevertising_X2)
  get_outliers(Years_X3)
}


