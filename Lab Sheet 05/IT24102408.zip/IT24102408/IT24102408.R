getwd()
setwd("C:\\Users\\Aathooran\\Desktop\\IT24102408")
list.files()

DeliveryTimes <- read.table("Exercise - Lab 05.txt", header = FALSE)
colnames(DeliveryTimes) <- c("Time")

DeliveryTimes$Time <- as.numeric(as.character(DeliveryTimes$Time))

breaks <- seq(20, 70, length.out = 10)   # 9 intervals means 10 break points
hist(DeliveryTimes$Time,
     breaks = breaks,
     right = FALSE,     
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time",
     ylab = "Frequency",
     col = "lightblue",
     border = "black")


hist_data <- hist(DeliveryTimes$Time,
                  breaks = breaks,
                  right = FALSE,
                  plot = FALSE)

cum_freq <- c(0, cumsum(hist_data$counts))  # cumulative frequencies
plot(breaks, cum_freq,
     type = "o",
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time",
     ylab = "Cumulative Frequency",
     col = "blue",
     pch = 16)
